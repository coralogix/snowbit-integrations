from main import Main
import os


def lambda_handler(event, context):
    cur_run = Main(event["body"], os.getenv("API_KEY"), os.getenv("CX_GRPC_REGION")).main()

