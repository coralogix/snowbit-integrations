import json
import os
from datetime import datetime

def lambda_handler(event, context):
    """Minimal 1Password to Coralogix Lambda - replaces your Docker container"""
    
    try:
        # Import requests here to handle import errors gracefully
        import requests
    except ImportError:
        print("ERROR: requests library not found. Make sure it's included in the deployment package.")
        return {
            'statusCode': 500, 
            'body': json.dumps('Missing requests library - check deployment package')
        }
    
    print(f"Lambda started at {datetime.utcnow().isoformat()}")
    
    # Get environment variables
    onepassword_token = os.environ.get('ONEPASSWORD_TOKEN')
    coralogix_private_key = os.environ.get('CORALOGIX_PRIVATE_KEY')
    coralogix_region = os.environ.get('CORALOGIX_REGION', 'eu2')
    application_name = os.environ.get('CORALOGIX_APPLICATION', '1Password')
    subsystem_name = os.environ.get('CORALOGIX_SUBSYSTEM', 'Events')
    
    # Map region codes to Coralogix domains
    region_domains = {
        'eu1': 'eu1.coralogix.com',
        'eu2': 'eu2.coralogix.com',
        'ap1': 'ap1.coralogix.com',
        'ap2': 'ap2.coralogix.com',
        'us1': 'us1.coralogix.com',
        'us2': 'us2.coralogix.com'
    }
    
    coralogix_domain = region_domains.get(coralogix_region.lower(), 'coralogix.com')
    
    print(f"Environment check - Token: {'✓' if onepassword_token else '✗'}, Key: {'✓' if coralogix_private_key else '✗'}, Region: {coralogix_region}, Domain: {coralogix_domain}")
    
    if not onepassword_token or not coralogix_private_key:
        return {
            'statusCode': 400, 
            'body': json.dumps('Missing required environment variables: ONEPASSWORD_TOKEN or CORALOGIX_PRIVATE_KEY')
        }
    
    # 1Password API headers
    headers = {
        'Authorization': f'Bearer {onepassword_token}',
        'Content-Type': 'application/json'
    }
    
    # Fetch and send events (same as your Docker container)
    # 1Password Events API uses POST requests, not GET
    event_types = ['signinattempts', 'itemusages', 'auditevents']
    total_events = 0
    errors = []
    
    for event_type in event_types:
        try:
            print(f"Fetching {event_type} events...")
            
            # Fetch from 1Password API using POST method
            url = f"https://events.1password.com/api/v1/{event_type}"
            
            # 1Password Events API requires POST with JSON payload
            # Get events from the last hour to avoid too much data
            from datetime import timedelta
            five_minutes_ago = (datetime.utcnow() - timedelta(minutes=5)).isoformat() + "Z"
            
            payload = {
                "limit": 1000,
                "start_time": five_minutes_ago
            }
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            
            if response.status_code != 200:
                error_msg = f"1Password API error for {event_type}: {response.status_code} - {response.text}"
                print(error_msg)
                errors.append(error_msg)
                continue
                
            response.raise_for_status()
            data = response.json()
            events = data.get('items', [])
            
            print(f"Found {len(events)} {event_type} events")
            
            if not events:
                print(f"No {event_type} events to process")
                continue
            
            # Send events to Coralogix using /logs/v1/singles endpoint
            coralogix_url = f"https://ingress.{coralogix_domain}/logs/v1/singles"
            coralogix_headers = {
                'Authorization': f'Bearer {coralogix_private_key}',
                'Content-Type': 'application/json'
            }
            
            # Build log entries as array
            log_entries = []
            for event in events:
                # Add event_type to help identify the source
                event['event_type'] = event_type
                log_entries.append({
                    'applicationName': application_name,
                    'subsystemName': subsystem_name,
                    'text': json.dumps(event)
                })
            
            try:
                # Send as array
                coralogix_response = requests.post(
                    coralogix_url,
                    headers=coralogix_headers,
                    json=log_entries,
                    timeout=30
                )
                
                if coralogix_response.status_code not in [200, 201]:
                    print(f"Coralogix error: {coralogix_response.status_code} - {coralogix_response.text}")
                    errors.append(f"Coralogix error for {event_type}: {coralogix_response.status_code}")
                else:
                    sent_count = len(events)
                    print(f"Successfully sent {sent_count} {event_type} events to Coralogix")
                    total_events += sent_count
                    
            except Exception as e:
                print(f"Error sending events to Coralogix: {e}")
                errors.append(f"Error sending {event_type} to Coralogix: {str(e)}")
            
        except Exception as e:
            error_msg = f"Error processing {event_type}: {str(e)}"
            print(error_msg)
            errors.append(error_msg)
    
    # Prepare response
    result = {
        'total_events_processed': total_events,
        'timestamp': datetime.utcnow().isoformat(),
        'errors': errors if errors else None
    }
    
    print(f"Lambda completed: {json.dumps(result)}")
    
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    } 